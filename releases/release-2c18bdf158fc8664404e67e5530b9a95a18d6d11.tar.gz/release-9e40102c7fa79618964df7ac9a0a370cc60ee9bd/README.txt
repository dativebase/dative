================================================================================
  Dative 2c18bdf158fc8664404e67e5530b9a95a18d6d11 Licenses
================================================================================

This directory contains all of the licenses for all of the dependencies of
Dative at release 2c18bdf158fc8664404e67e5530b9a95a18d6d11.

See licenses/licenses.json for the JSON output of npm-license-crawler, i.e., an
object mapping dependency identifiers to metadata, including the URL where the
text of the license can be found.

All of the other sub-directories in this directory are the identifiers of
dependencies and each should contain a LICENSE file containing the dependency's
license. E.g., lodash@3.10.1/LICENSE contains the license text for the Lodash v.
3.10.1 dependency.

I was unable to locate licenses for the following dependencies:

- uid2@0.0.3
- batch@0.5.0
- bytes@0.2.1
- superclick@1.1.0
- find-file@0.1.4
- pause@0.0.1
- growl@1.7.0
- cookie-signature@1.0.1
- range-parser@0.0.4
